import logo from './logo.svg';
import './App.css';
import CommentSection from './Comments/CommentSection';

function App() {
  return (
    <div className="App">
      <CommentSection />
    </div>
  );
}

export default App;
