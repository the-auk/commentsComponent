const getComments = async(pool) => {
    try{
        const client = await pool.connect();
        const queryText = `SELECT * FROM public.comments`
        let result = await client.query(queryText);
        client.release();
        return result.rows
    }
    catch (err){
        throw err
    }
}

const addComment = async(pool, comment) => {
    try{
        const client = await pool.connect();
        const queryText = `INSERT INTO public.comments (id, author, comment_text, date, likes, image) 
                            VALUES ($1, $2, $3, $4, $5, $6)`
        //run another service here that uploads the image to GCP storage or AWS S3 and fetches an image URL or would have to store image as bitmap
        await client.query(queryText, [comment.id, comment.author, comment.text, comment.date, comment.likes, comment.image])
        client.release()
        return true
    }
    catch (err){
        return false
    }
}

const updateComment = async(pool, updatedComment) => {
    try{
        const client = await pool.connect();
        const queryText = `UPDATE public.comments SET comment_text = $2 WHERE id = $1`
        await client.query(queryText, [updatedComment.id, updatedComment.text])
        client.release()
        return true
    }
    catch (err) {
        return false
    }
}

const deleteComment = async(pool, commentId) => {
    try{
        const client = await pool.connect();
        const queryText = `DELETE FROM public.comments WHERE id = $1`
        await client.query(queryText, [commentId])
        client.release()
        return true
    }
    catch (err) {
        return false
    }
}

exports.getComments = getComments;
exports.addComment = addComment;
exports.updateComment = updateComment;
exports.deleteComment = deleteComment;