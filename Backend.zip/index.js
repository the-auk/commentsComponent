const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const dbFunctions = require('./dbService')
const {Pool} = require('pg')

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const dbUser = 'tanmay';
const dbPassword = 'tanmay1T!';
const dbName = 'postgres';

// const dbConfig = {
//     user:dbUser,
//     password:dbPassword,
//     database:dbName,
//     omitNull:true,
//     host : '127.0.0.1',
//     port : '5432'
// }
const appDbConfig = {
    user:dbUser,
    password:dbPassword,
    database:dbName,
    omitNull:true,
    host: `/cloudsql/bobyard-406805:us-west1:bobyard`
}
const pool = new Pool(appDbConfig)

app.get('/getComments', async (req, res) => {
  const result = await dbFunctions.getComments(pool);
  res.status(200).send(result);
});

app.put('/addComment', async (req, res) =>{
    const comment = req.body;
    const result = await dbFunctions.addComment(pool, comment)
    if(result){
        res.sendStatus(200)
    }
    else{
        res.sendStatus(400)
    }
})

app.post('/updateComment', async (req, res) => {
    const updatedComment = req.body;
    console.log(updatedComment)
    const result = await dbFunctions.updateComment(pool, updatedComment);
    if(result){
        res.sendStatus(200)
    }
    else{
        res.sendStatus(400)
    }
})

app.delete('/deleteComment/:id', async (req, res) =>{
    const {id} = req.params;
    console.log(id)
    const result = await dbFunctions.deleteComment(pool, id);
    if(result){
        res.sendStatus(200)
    }
    else{
        res.sendStatus(400)
    }
})

const PORT = process.env.PORT || 8080;
    app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});